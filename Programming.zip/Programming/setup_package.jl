# add packages
Pkg.add("MAT")
Pkg.add("Distances")
Pkg.add("Distributions")
Pkg.add("Plots")
Pkg.add("PyPlot")

# compile packages (first time use)
using MAT
using Distances
using Distributions
using Plots
pyplot()
